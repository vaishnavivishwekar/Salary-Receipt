import { useState } from "react";
import { motion } from "framer-motion";
import {
  LayoutDashboard,
  FileSpreadsheet,
  FileText,
  PenTool,
  BarChart3,
  Bell,
  ChevronDown,
  Upload,
  Send,
  Users,
  CheckCircle2,
  Clock,
  AlertTriangle,
  TrendingUp,
  Wallet,
  Building2,
  Activity,
  FileCheck,
  MessageSquare,
  Calendar,
  Search,
  Menu,
  X,
  CircleDollarSign,
  Briefcase,
  Timer,
  Shield,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Progress } from "@/components/ui/progress";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";

const navItems = [
  { icon: LayoutDashboard, label: "Dashboard", active: true },
  { icon: FileSpreadsheet, label: "Upload Excel", active: false },
  { icon: FileText, label: "Generate Receipts", active: false },
  { icon: PenTool, label: "Manual Receipt", active: false },
  { icon: BarChart3, label: "Reports", active: false },
];

const summaryCards = [
  {
    title: "Total Workers",
    value: "156",
    icon: Users,
    change: "+12 this month",
    color: "bg-blue-500",
    lightColor: "bg-blue-50",
    textColor: "text-blue-600",
  },
  {
    title: "Excel Uploaded",
    value: "Yes",
    icon: FileSpreadsheet,
    change: "Dec 2025 data",
    color: "bg-emerald-500",
    lightColor: "bg-emerald-50",
    textColor: "text-emerald-600",
  },
  {
    title: "Receipts Generated",
    value: "142",
    icon: FileCheck,
    change: "91% complete",
    color: "bg-violet-500",
    lightColor: "bg-violet-50",
    textColor: "text-violet-600",
  },
  {
    title: "Pending Receipts",
    value: "14",
    icon: Clock,
    change: "Awaiting action",
    color: "bg-amber-500",
    lightColor: "bg-amber-50",
    textColor: "text-amber-600",
  },
];

const alerts = [
  {
    type: "warning",
    message: "3 records have missing bank details",
    icon: AlertTriangle,
  },
  {
    type: "info",
    message: "5 workers have overtime > 40 hours",
    icon: Timer,
  },
  {
    type: "pending",
    message: "14 salary receipts pending to send",
    icon: Send,
  },
];

const recentActivities = [
  {
    action: "Excel uploaded",
    detail: "December_Salary_2025.xlsx",
    time: "2 hours ago",
    icon: Upload,
    color: "text-blue-500",
    bgColor: "bg-blue-50",
  },
  {
    action: "Receipts generated",
    detail: "142 salary slips created",
    time: "1 hour ago",
    icon: FileText,
    color: "text-emerald-500",
    bgColor: "bg-emerald-50",
  },
  {
    action: "WhatsApp sent",
    detail: "128 receipts delivered",
    time: "45 mins ago",
    icon: MessageSquare,
    color: "text-green-500",
    bgColor: "bg-green-50",
  },
  {
    action: "Manual receipt",
    detail: "Created for Raj Kumar",
    time: "30 mins ago",
    icon: PenTool,
    color: "text-violet-500",
    bgColor: "bg-violet-50",
  },
];

const payrollOverview = [
  {
    label: "Total Salary Payout",
    value: "₹24,56,780",
    icon: Wallet,
    color: "text-blue-600",
    bgColor: "bg-blue-100",
  },
  {
    label: "Total Overtime Cost",
    value: "₹1,82,450",
    icon: TrendingUp,
    color: "text-amber-600",
    bgColor: "bg-amber-100",
  },
  {
    label: "Total PF Deduction",
    value: "₹2,94,814",
    icon: Shield,
    color: "text-emerald-600",
    bgColor: "bg-emerald-100",
  },
];

export default function Dashboard() {
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [selectedMonth, setSelectedMonth] = useState("dec-2025");

  return (
    <div className="flex h-screen bg-background overflow-hidden">
      {/* Sidebar */}
      <motion.aside
        initial={{ x: -280 }}
        animate={{ x: sidebarOpen ? 0 : -280 }}
        transition={{ type: "spring", damping: 25, stiffness: 200 }}
        className="fixed lg:relative z-40 w-[280px] h-full bg-sidebar text-sidebar-foreground flex flex-col shadow-xl"
      >
        {/* Logo */}
        <div className="flex items-center gap-3 px-6 py-5 border-b border-sidebar-border">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center shadow-lg">
            <CircleDollarSign className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-lg font-bold tracking-tight">PayrollPro</h1>
            <p className="text-xs text-sidebar-foreground/60">Salary Management</p>
          </div>
          <Button
            variant="ghost"
            size="icon"
            className="ml-auto lg:hidden text-sidebar-foreground hover:bg-sidebar-accent"
            onClick={() => setSidebarOpen(false)}
            data-testid="close-sidebar"
          >
            <X className="w-5 h-5" />
          </Button>
        </div>

        {/* Navigation */}
        <ScrollArea className="flex-1 py-4">
          <nav className="px-3 space-y-1">
            {navItems.map((item, index) => (
              <motion.button
                key={item.label}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.05 }}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all duration-200 ${
                  item.active
                    ? "bg-sidebar-primary text-sidebar-primary-foreground shadow-lg shadow-blue-500/25"
                    : "text-sidebar-foreground/70 hover:bg-sidebar-accent hover:text-sidebar-foreground"
                }`}
                data-testid={`nav-${item.label.toLowerCase().replace(/\s/g, "-")}`}
              >
                <item.icon className="w-5 h-5" />
                {item.label}
                {item.label === "Generate Receipts" && (
                  <Badge className="ml-auto bg-amber-500 text-white text-[10px] px-1.5 py-0.5">
                    14
                  </Badge>
                )}
              </motion.button>
            ))}
          </nav>

          <Separator className="my-4 bg-sidebar-border" />

          {/* Workflow Info */}
          <div className="px-6">
            <p className="text-xs font-medium text-sidebar-foreground/50 uppercase tracking-wider mb-3">
              Workflow
            </p>
            <div className="space-y-2 text-xs text-sidebar-foreground/70">
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 rounded-full bg-blue-500/20 flex items-center justify-center text-blue-400 text-[10px] font-bold">
                  1
                </div>
                <span>Upload Excel</span>
              </div>
              <div className="w-px h-3 bg-sidebar-border ml-3" />
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 rounded-full bg-blue-500/20 flex items-center justify-center text-blue-400 text-[10px] font-bold">
                  2
                </div>
                <span>Generate Receipts</span>
              </div>
              <div className="w-px h-3 bg-sidebar-border ml-3" />
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 rounded-full bg-blue-500/20 flex items-center justify-center text-blue-400 text-[10px] font-bold">
                  3
                </div>
                <span>Send via WhatsApp</span>
              </div>
            </div>
          </div>
        </ScrollArea>

        {/* Admin Info */}
        <div className="p-4 border-t border-sidebar-border">
          <div className="flex items-center gap-3 p-3 rounded-xl bg-sidebar-accent">
            <Avatar className="w-10 h-10 border-2 border-blue-500">
              <AvatarImage src="" />
              <AvatarFallback className="bg-gradient-to-br from-blue-500 to-blue-600 text-white font-semibold">
                AD
              </AvatarFallback>
            </Avatar>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold truncate">Admin User</p>
              <p className="text-xs text-sidebar-foreground/60 truncate">
                admin@company.com
              </p>
            </div>
          </div>
        </div>
      </motion.aside>

      {/* Mobile Sidebar Overlay */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-30 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Main Content */}
      <main className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Top Header */}
        <header className="sticky top-0 z-20 bg-card border-b border-border px-4 lg:px-8 py-4">
          <div className="flex items-center justify-between gap-4">
            <div className="flex items-center gap-4">
              <Button
                variant="ghost"
                size="icon"
                className="lg:hidden"
                onClick={() => setSidebarOpen(true)}
                data-testid="open-sidebar"
              >
                <Menu className="w-5 h-5" />
              </Button>
              <div className="hidden sm:flex items-center gap-3 bg-muted/50 rounded-xl px-4 py-2.5">
                <Calendar className="w-4 h-4 text-muted-foreground" />
                <Select value={selectedMonth} onValueChange={setSelectedMonth}>
                  <SelectTrigger
                    className="border-0 bg-transparent p-0 h-auto shadow-none focus:ring-0 w-[140px]"
                    data-testid="month-selector"
                  >
                    <SelectValue placeholder="Select month" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="dec-2025">December 2025</SelectItem>
                    <SelectItem value="nov-2025">November 2025</SelectItem>
                    <SelectItem value="oct-2025">October 2025</SelectItem>
                    <SelectItem value="sep-2025">September 2025</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="hidden md:flex items-center gap-2 bg-muted/50 rounded-xl px-4 py-2.5">
                <Search className="w-4 h-4 text-muted-foreground" />
                <input
                  type="text"
                  placeholder="Search workers..."
                  className="bg-transparent border-0 outline-none text-sm w-40 placeholder:text-muted-foreground"
                  data-testid="search-input"
                />
              </div>

              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="relative"
                    data-testid="notifications-button"
                  >
                    <Bell className="w-5 h-5" />
                    <span className="absolute -top-0.5 -right-0.5 w-4 h-4 bg-red-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center">
                      3
                    </span>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-80">
                  <DropdownMenuLabel>Notifications</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem className="flex gap-3 py-3">
                    <div className="w-8 h-8 rounded-full bg-amber-100 flex items-center justify-center">
                      <AlertTriangle className="w-4 h-4 text-amber-600" />
                    </div>
                    <div>
                      <p className="text-sm font-medium">Missing bank details</p>
                      <p className="text-xs text-muted-foreground">
                        3 workers need attention
                      </p>
                    </div>
                  </DropdownMenuItem>
                  <DropdownMenuItem className="flex gap-3 py-3">
                    <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center">
                      <FileSpreadsheet className="w-4 h-4 text-blue-600" />
                    </div>
                    <div>
                      <p className="text-sm font-medium">Excel processed</p>
                      <p className="text-xs text-muted-foreground">
                        156 records imported
                      </p>
                    </div>
                  </DropdownMenuItem>
                  <DropdownMenuItem className="flex gap-3 py-3">
                    <div className="w-8 h-8 rounded-full bg-emerald-100 flex items-center justify-center">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    </div>
                    <div>
                      <p className="text-sm font-medium">Receipts sent</p>
                      <p className="text-xs text-muted-foreground">
                        128 delivered via WhatsApp
                      </p>
                    </div>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>

              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button
                    variant="ghost"
                    className="gap-2 px-2"
                    data-testid="admin-profile-button"
                  >
                    <Avatar className="w-8 h-8">
                      <AvatarFallback className="bg-gradient-to-br from-blue-500 to-blue-600 text-white text-xs font-semibold">
                        AD
                      </AvatarFallback>
                    </Avatar>
                    <span className="hidden lg:inline text-sm font-medium">
                      Admin
                    </span>
                    <ChevronDown className="w-4 h-4 text-muted-foreground" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuLabel>My Account</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem>Profile Settings</DropdownMenuItem>
                  <DropdownMenuItem>Company Settings</DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem className="text-red-600">
                    Log out
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </header>

        {/* Dashboard Content */}
        <ScrollArea className="flex-1">
          <div className="p-4 lg:p-8 space-y-6">
            {/* Page Title */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h2 className="text-2xl lg:text-3xl font-bold text-foreground">
                  Dashboard
                </h2>
                <p className="text-muted-foreground mt-1">
                  Welcome back! Here's your payroll overview for December 2025.
                </p>
              </div>
              <div className="flex gap-3">
                <Button
                  variant="outline"
                  className="gap-2"
                  data-testid="button-upload-excel"
                >
                  <Upload className="w-4 h-4" />
                  <span className="hidden sm:inline">Upload Excel</span>
                </Button>
                <Button className="gap-2" data-testid="button-generate-receipts">
                  <FileText className="w-4 h-4" />
                  <span className="hidden sm:inline">Generate Receipts</span>
                </Button>
              </div>
            </div>

            {/* Summary Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6">
              {summaryCards.map((card, index) => (
                <motion.div
                  key={card.title}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Card
                    className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 overflow-hidden"
                    data-testid={`card-${card.title.toLowerCase().replace(/\s/g, "-")}`}
                  >
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between">
                        <div>
                          <p className="text-sm font-medium text-muted-foreground">
                            {card.title}
                          </p>
                          <p className="text-3xl font-bold mt-2 tracking-tight">
                            {card.value}
                          </p>
                          <p className={`text-xs mt-2 ${card.textColor}`}>
                            {card.change}
                          </p>
                        </div>
                        <div
                          className={`w-12 h-12 rounded-xl ${card.lightColor} flex items-center justify-center`}
                        >
                          <card.icon className={`w-6 h-6 ${card.textColor}`} />
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>

            {/* Status Banner */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
            >
              <Card
                className="border-0 shadow-lg bg-gradient-to-r from-blue-600 to-blue-700 text-white overflow-hidden"
                data-testid="status-banner"
              >
                <CardContent className="p-6">
                  <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                    <div className="flex items-center gap-4">
                      <div className="w-14 h-14 rounded-2xl bg-white/20 flex items-center justify-center">
                        <Activity className="w-7 h-7" />
                      </div>
                      <div>
                        <h3 className="text-lg font-bold">
                          Payroll Status: In Progress
                        </h3>
                        <p className="text-blue-100 text-sm mt-1">
                          142 of 156 salary receipts have been generated. 14
                          receipts pending.
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="flex-1 lg:w-48">
                        <div className="flex justify-between text-sm mb-2">
                          <span>Progress</span>
                          <span className="font-semibold">91%</span>
                        </div>
                        <Progress
                          value={91}
                          className="h-2 bg-white/20"
                          data-testid="progress-bar"
                        />
                      </div>
                      <Button
                        variant="secondary"
                        className="bg-white text-blue-600 hover:bg-blue-50 font-semibold shadow-lg"
                        data-testid="button-complete-pending"
                      >
                        Complete Pending
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            {/* Three Column Layout */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Alerts & Tasks */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5 }}
              >
                <Card
                  className="border-0 shadow-lg h-full"
                  data-testid="alerts-panel"
                >
                  <CardHeader className="pb-4">
                    <CardTitle className="text-lg font-bold flex items-center gap-2">
                      <AlertTriangle className="w-5 h-5 text-amber-500" />
                      Alerts & Tasks
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    {alerts.map((alert, index) => (
                      <div
                        key={index}
                        className={`flex items-start gap-3 p-4 rounded-xl ${
                          alert.type === "warning"
                            ? "bg-amber-50 border border-amber-100"
                            : alert.type === "info"
                            ? "bg-blue-50 border border-blue-100"
                            : "bg-orange-50 border border-orange-100"
                        }`}
                        data-testid={`alert-${index}`}
                      >
                        <div
                          className={`w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 ${
                            alert.type === "warning"
                              ? "bg-amber-100"
                              : alert.type === "info"
                              ? "bg-blue-100"
                              : "bg-orange-100"
                          }`}
                        >
                          <alert.icon
                            className={`w-4 h-4 ${
                              alert.type === "warning"
                                ? "text-amber-600"
                                : alert.type === "info"
                                ? "text-blue-600"
                                : "text-orange-600"
                            }`}
                          />
                        </div>
                        <p className="text-sm font-medium text-foreground">
                          {alert.message}
                        </p>
                      </div>
                    ))}
                  </CardContent>
                </Card>
              </motion.div>

              {/* Payroll Overview */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.6 }}
              >
                <Card
                  className="border-0 shadow-lg h-full"
                  data-testid="payroll-overview-panel"
                >
                  <CardHeader className="pb-4">
                    <CardTitle className="text-lg font-bold flex items-center gap-2">
                      <Briefcase className="w-5 h-5 text-blue-500" />
                      Payroll Overview
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {payrollOverview.map((item, index) => (
                      <div
                        key={index}
                        className="flex items-center gap-4 p-4 rounded-xl bg-muted/50"
                        data-testid={`payroll-${item.label
                          .toLowerCase()
                          .replace(/\s/g, "-")}`}
                      >
                        <div
                          className={`w-12 h-12 rounded-xl ${item.bgColor} flex items-center justify-center`}
                        >
                          <item.icon className={`w-6 h-6 ${item.color}`} />
                        </div>
                        <div className="flex-1">
                          <p className="text-sm text-muted-foreground">
                            {item.label}
                          </p>
                          <p className="text-xl font-bold tracking-tight">
                            {item.value}
                          </p>
                        </div>
                      </div>
                    ))}
                  </CardContent>
                </Card>
              </motion.div>

              {/* Recent Activity */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.7 }}
              >
                <Card
                  className="border-0 shadow-lg h-full"
                  data-testid="recent-activity-panel"
                >
                  <CardHeader className="pb-4">
                    <CardTitle className="text-lg font-bold flex items-center gap-2">
                      <Activity className="w-5 h-5 text-emerald-500" />
                      Recent Activity
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {recentActivities.map((activity, index) => (
                        <div
                          key={index}
                          className="flex items-start gap-3"
                          data-testid={`activity-${index}`}
                        >
                          <div
                            className={`w-9 h-9 rounded-lg ${activity.bgColor} flex items-center justify-center flex-shrink-0`}
                          >
                            <activity.icon
                              className={`w-4 h-4 ${activity.color}`}
                            />
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-medium">{activity.action}</p>
                            <p className="text-xs text-muted-foreground truncate">
                              {activity.detail}
                            </p>
                          </div>
                          <span className="text-xs text-muted-foreground whitespace-nowrap">
                            {activity.time}
                          </span>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            </div>

            {/* Quick Actions */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.8 }}
            >
              <Card
                className="border-0 shadow-lg"
                data-testid="quick-actions-panel"
              >
                <CardHeader className="pb-4">
                  <CardTitle className="text-lg font-bold">
                    Quick Actions
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <Button
                      variant="outline"
                      className="h-auto py-6 flex flex-col items-center gap-3 hover:bg-blue-50 hover:border-blue-200 hover:text-blue-600 transition-all group"
                      data-testid="quick-action-upload-excel"
                    >
                      <div className="w-14 h-14 rounded-2xl bg-blue-100 group-hover:bg-blue-200 flex items-center justify-center transition-colors">
                        <Upload className="w-7 h-7 text-blue-600" />
                      </div>
                      <div className="text-center">
                        <p className="font-semibold">Upload Excel</p>
                        <p className="text-xs text-muted-foreground mt-1">
                          Bulk salary data
                        </p>
                      </div>
                    </Button>

                    <Button
                      variant="outline"
                      className="h-auto py-6 flex flex-col items-center gap-3 hover:bg-emerald-50 hover:border-emerald-200 hover:text-emerald-600 transition-all group"
                      data-testid="quick-action-generate-receipts"
                    >
                      <div className="w-14 h-14 rounded-2xl bg-emerald-100 group-hover:bg-emerald-200 flex items-center justify-center transition-colors">
                        <FileText className="w-7 h-7 text-emerald-600" />
                      </div>
                      <div className="text-center">
                        <p className="font-semibold">Generate Receipts</p>
                        <p className="text-xs text-muted-foreground mt-1">
                          Auto per worker
                        </p>
                      </div>
                    </Button>

                    <Button
                      variant="outline"
                      className="h-auto py-6 flex flex-col items-center gap-3 hover:bg-green-50 hover:border-green-200 hover:text-green-600 transition-all group"
                      data-testid="quick-action-send-whatsapp"
                    >
                      <div className="w-14 h-14 rounded-2xl bg-green-100 group-hover:bg-green-200 flex items-center justify-center transition-colors">
                        <Send className="w-7 h-7 text-green-600" />
                      </div>
                      <div className="text-center">
                        <p className="font-semibold">Send via WhatsApp</p>
                        <p className="text-xs text-muted-foreground mt-1">
                          Deliver salary slips
                        </p>
                      </div>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </ScrollArea>
      </main>
    </div>
  );
}